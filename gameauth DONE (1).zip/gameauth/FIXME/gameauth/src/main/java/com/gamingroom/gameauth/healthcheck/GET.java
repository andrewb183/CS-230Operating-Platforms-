package com.gamingroom.gameauth.healthcheck;

public @interface GET {

}
